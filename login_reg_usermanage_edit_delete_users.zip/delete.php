<?php 

$id=$_GET["id"];

$h ="localhost";
$u ="root";
$p ="";
$db ="test";

$conn = mysqli_connect($h,$u,$p,$db);

if (!$conn) {
    echo "Not COnnected". mysqli_connect_error();
} 

$sql = "DELETE FROM `users` WHERE `users`.`id` = $id";

if (mysqli_query($conn,$sql)) {
    header("Location: usermanage.php");
} else {
    echo "something went wrong".mysqli_error($conn);
}


mysqli_close($conn);

?>
<?php 

$uname=$_GET["uname"];
$pass=$_GET["pass"];

echo " $uname $pass";
?>
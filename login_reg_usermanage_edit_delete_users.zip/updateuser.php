<?php 

$id=$_POST["id"];
$name=$_POST["name"];
$email=$_POST["email"];
$uname=$_POST["uname"];
$pass=$_POST["pass"];

$h ="localhost";
$u ="root";
$p ="";
$db ="test";

$conn = mysqli_connect($h,$u,$p,$db);

if (!$conn) {
    echo "Not COnnected". mysqli_connect_error();
} 

$sql = "UPDATE `users` SET `name` = '$name', `email` = '$email', `username` = '$uname', `password` = '$pass' WHERE `users`.`id` = $id;";

if (mysqli_query($conn,$sql)) {
    header("Location: usermanage.php");
} else {
    echo "something went wrong".mysqli_error($conn);
}


mysqli_close($conn);

?>
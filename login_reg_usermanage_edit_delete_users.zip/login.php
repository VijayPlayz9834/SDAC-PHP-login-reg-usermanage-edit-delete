<?php 

$uname=$_POST["uname"];
$pass=$_POST["pass"];

$h ="localhost";
$u ="root";
$p ="";
$db ="test";

$conn = mysqli_connect($h,$u,$p,$db);

if (!$conn) {
    echo "Not COnnected". mysqli_connect_error();
} 

$sql = "SELECT * FROM `users` WHERE `username` = '$uname' AND `password` = '$pass'";

$result = mysqli_query($conn,$sql);

if (mysqli_num_rows($result)>0) {
    header("Location: usermanage.php");
} else {
    echo "Invalid Credentials <a href='login.html'>Try Again</a>";
}




mysqli_close($conn);

?>
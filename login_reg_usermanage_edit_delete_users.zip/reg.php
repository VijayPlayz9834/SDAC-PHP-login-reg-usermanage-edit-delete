<?php 


$name=$_POST["name"];
$email=$_POST["email"];
$uname=$_POST["uname"];
$pass=$_POST["pass"];

$h ="localhost";
$u ="root";
$p ="";
$db ="test";

$conn = mysqli_connect($h,$u,$p,$db);

if (!$conn) {
    echo "Not COnnected". mysqli_connect_error();
} 

$sql = "INSERT INTO `users` (`id`, `name`, `email`, `username`, `password`) VALUES (NULL, '$name', '$email', '$uname', '$pass');";

if (mysqli_query($conn,$sql)) {
    header("Location: Login.html");
} else {
    echo "something went wrong".mysqli_error($conn);
}


mysqli_close($conn);

?>